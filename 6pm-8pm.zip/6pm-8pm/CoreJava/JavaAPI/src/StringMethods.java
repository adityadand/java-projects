
public class StringMethods {
public static void main(String[] args) {
	/*String s1=new String("mr. First Middle Last");
	System.out.println("Original Val  : "+s1);
		s1.toUpperCase();
	System.out.println("After Upper Case : "+s1);
		//System.out.println(s1.replaceAll("Java", "CPP"));
	//System.out.println("After Replace : "+s1);
		System.out.println(s1.substring(13));
		System.out.println(s1.substring(6,12));
		System.out.println(s1.indexOf("Middle"));
		System.out.println(s1.startsWith("mr."));
		*/
		/*String s2="Hello";
		char ch[]=s2.toCharArray();
		for (int i = ch.length-1; i >=0 ; i--) {
			System.out.print(ch[i]);
		}*/
		
		String s1=new String("      First   Middle Last      "); // Last First Middle
		System.out.println(s1.trim());
		/*System.out.println(s1.length());
		String str[]=s1.split(" ");
		System.out.println(str[2]+" "+str[0] + " "+str[1]);*/
		/*for (int i = 0; i < str.length; i++) {
			System.out.println(str[i]);
			
		}*/
}
}
