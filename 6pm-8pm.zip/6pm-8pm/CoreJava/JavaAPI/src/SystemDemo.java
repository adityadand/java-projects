import java.io.IOException;


public class SystemDemo {
public static void main(String[] args) throws IOException {
	System.out.println("Enter Name : ");
	/*char gender=(char) System.in.read();
	System.err.println("Enter Char is "+gender);*/
	int data=0;
	StringBuilder sbr=new StringBuilder();
		while((data=System.in.read())!='\n'){
			sbr.append((char)data);
		}
	System.err.println("Your Name : "+sbr);
}
}
