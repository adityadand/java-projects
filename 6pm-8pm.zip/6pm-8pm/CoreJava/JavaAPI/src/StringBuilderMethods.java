
public class StringBuilderMethods {
public static void main(String[] args) {
	StringBuilder sbr=new StringBuilder("Hello");
		System.out.println(sbr.capacity());
		System.out.println(sbr.length());
	sbr.append(" Welcoem to String Program");
	System.out.println(sbr);
	System.out.println(sbr.capacity());
	System.out.println(sbr.length());
	sbr.insert(6, "cpp ");
	System.out.println(sbr);
	System.out.println(sbr.reverse());
		
}
}
