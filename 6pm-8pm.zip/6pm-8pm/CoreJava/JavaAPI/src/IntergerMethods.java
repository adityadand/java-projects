
public class IntergerMethods {
	static int i=10;
public static void main(String[] args) {
	
	//Integer in=Integer.valueOf(i);
	Integer in=i; // Boxing
	//System.out.println(Integer.reverse(i));
	/*System.out.println(in.toBinaryString(i));
	String str=Integer.toString(i);
	String s1="23";
	String s2="43";
	int a=Integer.parseInt(s1);
	int b=Integer.parseInt(s2);
	System.out.println(s1+s2);*/
}
}
