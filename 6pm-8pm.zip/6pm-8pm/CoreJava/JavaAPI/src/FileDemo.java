import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Date;


public class FileDemo {
public static void main(String[] args) throws IOException{
	File file1=new File("Z:\\CoreJava");
	//System.out.println("Folder Created : "+file1.mkdir());
	//System.out.println("File Created : "+file1.createNewFile());
	//System.out.println("File Deleted : "+file1.delete());
	//System.out.println(new Date(file1.lastModified()));
	//System.out.println(file1.isHidden());
	//System.out.println(file1.canWrite());
	/*String files[]=file1.list();
	for (String f : files) {
		System.out.println(f);
	}*/
	//System.out.println(file1.isFile());
	//System.out.println(file1.isDirectory());
	File files[]=file1.listFiles();
	 for (File file : files) {
		if(file.isFile()){ 
			String name=file.getName();
			if(name.endsWith(".java"))
				System.out.println(name);
		
		}
	}
}
}
