package overriding;
public class VehicalDetails {
	public static void main(String[] args) {
		VehicalDetails user1=new VehicalDetails();
			user1.details(new TVS());
			user1.details(new Toyota());
			user1.details(new Bike());
	}
	public void details(Vehical v){
		v.getDetails();
	}
}

class Vehical{
	public void getDetails(){
		System.out.println("I am Vehical");
	}
}

class Bike extends Vehical{}
class TVS extends Bike{
	public void getDetails(){
		System.out.println("I am TVS Bike");
	}
}
class Car extends Vehical{}
class Toyota extends Car{
	public void getDetails(){
		System.out.println("I am Toyota Car");
	}
}