/**
 * 1. Must be done in sub class
 * 2. Method name must be same
 * 3. Input parameters must be same 
 * 4. Return type must be same or sub type(Covarient type)
 * 5. Access modifier must be same or less restrictive.
 * 6. Cannot override private methods
 * 7. cannot override final and static method
 */
package overriding;

public class OverridingDemo {
	public static void main(String[] args) {
		Person p=new Doctor();
			p.intro();
	}
}
class Person {
	void intro() {
		System.out.println("I am Person");
	}
}
class Doctor extends Person {
	void intro() {
		System.out.println("I am Doctor");
	}
}
class Developer extends Person {
	public void intro() {
		System.out.println("I am Software engg.");
	}
}
