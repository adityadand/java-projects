public class GenericeMethod {
	public static void main(String[] args) {
		GenericeMethod gm=new GenericeMethod();
			gm.<Integer>print(23);
			gm.print(2.3);
			gm.print("Abcd");
			gm.print(true);
	}

	public <abc>void print(abc a) {
		System.out.println("Your Value is : " + a);
	}
}
