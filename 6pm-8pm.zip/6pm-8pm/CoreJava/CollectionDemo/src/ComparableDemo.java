import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.TreeSet;
public class ComparableDemo {
public static void main(String[] args) {
	
	ArrayList<Integer> list=new ArrayList<Integer>();
		list.add(345);
		list.add(45);
		list.add(45);
		list.add(125);
		list.add(15);
		list.add(15);
		int add=list.get(0)+list.get(1);
	System.out.println(add);
	/*TreeSet set=new TreeSet(new SortByAge());
		set.add(new Student(1,"Abc",34));
		set.add(new Student(12,"xYZ",14));
		set.add(new Student(13,"lmN",44));
		set.add(new Student(6,"pQR",11));
		set.add(new Student(78,"Stu",32));
		set.add(new Student(54,"Abc",21));
		set.add(new Student(22,"ppp",22));
	System.out.println(set);*/
}
}
class SortByAge implements Comparator<Student>{
	public int compare(Student s1, Student s2) {
		if(s1.age>s2.age)
			return 1;
		else if(s1.age<s2.age)
			return -1;
		else return 0;
	}
		
}
class SortById implements Comparator{
	public int compare(Object obj1, Object obj2) {
		Student s1=(Student)obj1;
		Student s2=(Student)obj2;
		if(s1.id>s2.id)
			return 1;
		else if(s1.id<s2.id)
			return -1;
		else return 0;
	}	
}
class Student{
	int id;
	String name;
	int age;
	public Student(int id, String name, int age) {
		this.id = id;
		this.name = name;
		this.age = age;
	}
	public String toString() {
		return "("+id+"-"+name+" - "+age+")\n";
	}

}


