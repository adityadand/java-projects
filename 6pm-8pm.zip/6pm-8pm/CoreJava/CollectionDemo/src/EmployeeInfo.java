import java.util.TreeSet;
public class EmployeeInfo {
public static void main(String[] args) {
	TreeSet set=new TreeSet();
		set.add(new Emp(1,"Abc",45645.45));
		set.add(new Emp(34,"Xyz",215645.45));
		set.add(new Emp(12,"Pqr",56645.45));
		set.add(new Emp(768,"Lmn",445665.45));
		set.add(new Emp(456,"Abc",5675.45));
		set.add(new Emp(123,"STU",345676.45));
	System.out.println(set);
}
}
class Emp implements Comparable{
	int id;
	String name;
	double salary;
	public Emp(int id, String name, double salary) {
		this.id = id;
		this.name = name;
		this.salary = salary;
	}
	/*public int compareTo(Object obj) {
		Emp e=(Emp)obj;
		if(id>e.id){
			return 1;
		}else if( id < e.id){
			return -1;
		}else{
			return 0;
		}
	}*/
	
	/*public int compareTo(Object obj) {
		Emp e=(Emp)obj;
		return name.compareTo(e.name);
	}*/
	
	public int compareTo(Object obj) {
		Emp e=(Emp)obj;
		if(salary>e.salary){
			return 1;
		}else if( salary < e.salary){
			return -1;
		}else{
			return 0;
		}
	}
	
	@Override
	public String toString() {
		return "("+id+" - "+name+" - "+salary+")\n";
	}
}