import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.TreeMap;


public class MapDemo {
	public static void main(String[] args) {
		TreeMap map=new TreeMap();
			map.put(1, "xyz");
			map.put(2, "abc");
			map.put(56, "pqr");
			map.put(1, "lmn");
			map.put(134, 345);
		System.out.println(map);
		/*System.out.println(map.headMap(56));
		System.out.println(map.tailMap(56));*/
		System.err.println(map.higherKey(50)); //higher key than given key 
		System.err.println(map.ceilingKey(50));//equals or higher key than given key 
		System.err.println(map.lowerKey(50));//lower key than given key 
		System.err.println(map.floorKey(50));//equals or lower key than given key 
		
	}
}
