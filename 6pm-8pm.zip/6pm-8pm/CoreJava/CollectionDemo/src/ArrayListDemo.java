import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Stack;


public class ArrayListDemo {
public static void main(String[] args) {
	//ArrayList list=new ArrayList();
	/*	list.add("abc");
		list.add("xyz");
		list.add("pqr");
		list.add("abc");
		list.add(456456);
		System.out.println(list);
		list.add(2, "rpq");
		System.out.println(list);
		list.set(2, "test");
		System.out.println(list);
	
		System.out.println(list);
		ArrayList list1=new ArrayList();
		list1.add("abc");
		list1.add("xyz");
		
		list.retainAll(list1);
		
	System.out.println(list);*/
	
		
		
		
		/*list.remove("abc");
		System.out.println(list.contains("abc"));
		System.out.println(list.size());
		list.clear();
		System.out.println(list);
		*/

	/*Stack stack=new Stack();
		stack.addElement("abc");
		stack.addElement("pqr");
		stack.addElement("xyz");
		stack.addElement("lmn");
	//System.out.println(stack);
		stack.add("test1");
		stack.push("test");
	System.out.println(stack);
	//System.out.println(stack.peek());
	System.out.println(stack.pop());
	System.out.println(stack);*/
	
	
	LinkedList list=new LinkedList();
		/*list.add("abc");
		list.add("xyz");
		list.add("pqr");
		list.add("abc");
		list.add(456456);
		System.out.println(list);
	System.out.println(list.getLast());
	System.out.println(list.getFirst());*/
	
	System.out.println(list.peek());
	System.out.println("After peek : "+list);
	System.out.println(list.pop());//throws NoSuchElementException if no element found
	System.out.println("After pop : "+list);
	System.out.println(list.poll());//null value if no element found
	System.out.println("After poll : "+list);
}
}
