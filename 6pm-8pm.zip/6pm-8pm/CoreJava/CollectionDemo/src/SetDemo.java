import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class SetDemo {
	public static void main(String[] args) {
		HashSet set=new HashSet();
			set.add(new Employee(1, "abc"));
			set.add(new Employee(2, "xyz"));
			set.add(new Employee(3, "pqr"));
			set.add(new Employee(1, "abc"));
			set.add(new Employee(1, "xyz"));
			set.add(new Employee(1, "abc"));
		System.out.println(set);
		/*TreeSet set=new TreeSet();
			set.add(345);
			set.add(456);
			set.add(345);
			set.add(457);
			set.add(12);
			set.add(35);
			set.add(34);
			System.out.println(set);*/
	}
}

class Employee{
	int id;
	String name;
	public Employee(int id,String name) {
		this.id=id;
		this.name=name;
	}
	public int hashCode() {
		return id;
	}
	public boolean equals(Object obj) {
		Employee e=(Employee)obj;
		return id==e.id ? true : false;
	}
	
	
}

