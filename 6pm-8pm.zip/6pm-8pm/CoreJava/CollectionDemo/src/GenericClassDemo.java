
class Book{
	String name;
}
class Science extends Book{
	String name;
}
class History extends Book{
	String name;
}
class Computer extends Book{
	String name;
}
public class GenericClassDemo {
public static void main(String[] args) {
/*	GiftShop<History> shop=new GiftShop<History>();
		shop.wrapGift(new History());
		System.out.println(shop.sendGift());
		System.out.println("---------------------------");
*/		/*GiftShop<String> shop1=new GiftShop<String>();
		shop1.wrapGift("This is demo gift");
		System.out.println(shop1.sendGift());*/
}
}

interface GiftShop<Gift>{
	public void wrapGift(Gift g);
	public Gift sendGift();
}

class FlipkarGiftShop<Gift> implements GiftShop<Gift>{

	@Override
	public void wrapGift(Gift g) {
	
	}

	@Override
	public Gift sendGift() {
		return null;
	}
	
}
/*class GiftShop<Gift extends Book>{
	Gift g;
	public void wrapGift(Gift g){
		this.g=g;
		System.out.println("Gift wrapped");
	}
	
	public Gift sendGift(){
		System.out.println("Ready to send");
		return g;
	}
	
}*/
