import java.util.ArrayList;
import java.util.Iterator;


public class IteratorDemo {
public static void main(String[] args) {
	ArrayList list=new ArrayList();
		list.add(456);
		list.add(46);
		list.add(56);
		list.add(346);
		list.add(123);
		list.add(876);
		list.add(111);
	//System.out.println(list+"\n");
		Iterator it=list.iterator();
			while (it.hasNext()) {
				System.out.println(it.next());
			}
	
	

}
}

