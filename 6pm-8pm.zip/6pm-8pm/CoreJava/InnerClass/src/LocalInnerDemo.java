
public class LocalInnerDemo {
public static void main(String[] args) {
	new LocalOuter().print();
}
}

class LocalOuter{// outer class start
	private int a=10;
	
	public void print(){//Method Start
		final int b=20;
		class LocalInner{//Local Class Start
			public void display(){
				System.out.println(a);
				System.out.println(b);
			}
		}//Local Class Ends
		LocalInner in=new LocalInner();
			in.display();
	}//Method ends
	
}// outer class ends