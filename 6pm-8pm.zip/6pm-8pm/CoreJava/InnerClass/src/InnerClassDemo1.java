/** 
 * 1. Simple Inner class
 * 2. Static inner class
 * 3. Local inner class
 * 4. Anonymous inner class
 */
public class InnerClassDemo1 {
public static void main(String[] args) {
	Student s=new Student();
	Student.StudentAttendance sa=s.new StudentAttendance();
	//Student.StudentAttendance sa1=new Student().new StudentAttendance();
		sa.display();
}
}
class Student{ // Student.class
	private int id;
	private String name;
	class StudentAttendance{  // Student$StudentAttendance.class
		 private String attDate;
		private String status;
		
		public void display(){
			System.out.println(id);
			System.out.println(name);
		}
	}
	
}

