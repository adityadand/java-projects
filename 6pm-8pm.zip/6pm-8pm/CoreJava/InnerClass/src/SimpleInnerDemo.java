import javax.print.attribute.standard.MediaSize.Other;


public class SimpleInnerDemo {
	public static void main(String[] args) {
		//SimpleOuter out=new SimpleOuter();
		//SimpleOuter.SimpleInner in=out.new SimpleInner();
		SimpleOuter.SimpleInner in=new SimpleOuter().new SimpleInner();
			in.main();
			
		SimpleOuter.StaticInner staticIn=new SimpleOuter.StaticInner();
			staticIn.main();
	}
}



class SimpleOuter{ // Outer class Starts
	static private int a=10;
	static private void outerM(){
		System.out.println("I am Private from outer class");
		/*StaticInner in=new StaticInner();
			in.main();*/
	}
	
	 class SimpleInner{ // simple Inner class starts
		int x=20;
		public void main() {
			System.out.println(a);
			outerM();
		}
		
	}//simple Inner class Ends
	 
	static class StaticInner{// static Inner class starts
		public static void main() {
			System.out.println(a);
			outerM();
		}
		public static void main(String[] args) {
			System.out.println("I am Static Inner Class");
			outerM();
			main();
		}
	}// static Inner class ends to Run : java SimpleOuter$StaticInner
}// Outer class Ends



