
public class Employee
{
	byte id = 0B1010;
	long contact = 9078978978l;
	char gender = 'M';
	float salary = 768768.67F;
	boolean flag;
	
	public void display(){
		System.out.println(id);
		System.out.println(contact);
		System.out.println(gender);
		System.out.println(salary);
		System.out.println(flag);
	}

	public static void main(String a[])
	{
		Employee emp=new Employee();	
		System.out.println("Employee Info");		
		emp.display();
	}
}