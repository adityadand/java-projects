
public class TestObjectClass {
	public static void main(String[] args) {
		Product p1=new Product(1, "Abc");
		Product p2=new Product(3, "Xyz");
		Product p3=new Product(1, "PQR");
	}
}

class Product{
	int id;
	String name;
	
	public Product(int id, String name) {
		this.id = id;
		this.name = name;
	}
	
}


