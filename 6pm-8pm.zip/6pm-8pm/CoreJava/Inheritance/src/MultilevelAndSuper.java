/**
 * Every Sub class Constructor call super class default Constructor 
 * @author sumit.naikwadi
 *
 */
public class MultilevelAndSuper {
	public static void main(String[] args) {
		 C c=new C(); 
	}
}

class B extends java.lang.Object {
	int a=10;
	public void m(){
		System.out.println("M from B");
	}
}
class C extends B{
	int a=20;
	public void m(){
		
		System.out.println("M from C");
		System.out.println(super.a);
		super.m();
	}
	public C() {
		super();
		System.out.println("C");
	}
}

