
public class ObjectClassMethods {
	public static void main(String[] args) {
		Student stud1=new Student(1, "Abc");
		Student stud2=new Student(1, "Abc");
		System.out.println(stud1);
		System.out.println(stud2);
		System.out.println(stud1 == stud2);
			
	}
}

class Student{
	
	public String toString() {
		return id + " - " + name;
	}
	
	int id;
	String name;
	public Student(int id,String name) {
		this.id=id;
		this.name=name;
	}
}
