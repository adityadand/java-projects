import java.lang.annotation.Annotation;
import java.lang.annotation.Target;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;


public class RefelctionAPIDemo {
public static void main(String[] args) throws Exception {
	Class cls=Class.forName("Product");
	
/*	System.out.println("Class Name : " +cls.getName());
	Field f[]=cls.getFields();
	System.out.println("Total instance Variable : "+f.length);
	System.out.println("Instance variable info : ");
	for (Field field : f) {
		System.out.println(field);
	}
	
	Method methods[]=cls.getDeclaredMethods();
	System.out.println("Total methods : "+methods.length);
	for (Method method : methods) {
		System.out.println(method);
	}
	
	Constructor constructors[]=cls.getDeclaredConstructors();
	for (Constructor constructor : constructors) {
		System.out.println(constructor);
	}
	
	Annotation a[]=cls.getAnnotations();
	for (Annotation annotation : a) {
		if(annotation.toString().equals("@Table(name=ProductInfo)"))
			System.out.println("Create Table");	
	}
	*/
	/*Annotation tableAn=cls.getAnnotation(Target.class);
	System.out.println(tableAn);*/
	
	
	/*Field idField=cls.getField("id");
	System.out.println(idField);
	Annotation a[]=idField.getAnnotations();
	for (Annotation annotation : a) {
		System.out.println(annotation);
	}*/
	
	/*Method method=cls.getMethod("addInToCart");
	System.out.println(method);
	Annotation a[]=method.getAnnotations();
	for (Annotation annotation : a) {
		System.out.println(annotation);
	}*/
	
	Annotation a[]=cls.getAnnotations();
	for (Annotation annotation : a) {
		if(annotation.toString().equals("@Table(name=ProductInfo)")){
			Field f[]=cls.getFields();
			//for (Field field : f) {
				//System.out.println(field.getName() +" : "+field.getType());
				String query="create table product("+f[0].getName()+ " "+f[0].getType()+","+f[1].getName()+ " "+f[1].getType()+")";
				System.out.println(query);
			//}
		}
				
	}
}
}

@Table(name="ProductInfo")
class Product{
	@Column(name="pid")
	public int id;
	public String name;
	public double price;
	public int quantity;
	public Product() {
	}
	public Product(int id, String name, double price, int quantity) {
		this.id = id;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}
	
	public Product(int id, String name, double price) {
		this.id = id;
		this.name = name;
		this.price = price;
	}
	
	@MethodInfo(author="abc",createdOn="today",version=1.1f)
	public void addInToCart(){
		 System.out.println("Added successfully");
	}
	
	public void displayProduct(){
		 System.out.println("Display");
	 }
}
