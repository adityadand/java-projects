import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;


@Documented
@Inherited
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@interface MethodInfo{
	String author();
	float version();
	String createdOn();
}

public class Student {
	//@MethodInfo(author="abc",createdOn="9-sept-2017",version=1.1f)
	public String name;
	public String contact;
	
	public void displayDate(String email){
		System.out.println(name);
		System.out.println(contact);
	}
}

