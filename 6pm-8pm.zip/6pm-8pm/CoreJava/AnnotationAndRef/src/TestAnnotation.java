import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;


public class TestAnnotation {
public static void main(String[] args) {
	
}
}
/*
 * Retention Type
 * Source - use to create annotation for source file and ignore by compiler and interpreter
 * Class - use by Compiler.
 * Runtime - User by interpreter
 */

@Documented
@Retention(RetentionPolicy.RUNTIME)
@interface ClassInfo{
	String author();
	float version();
	String createdOn();
}

@ClassInfo(author="Abc",version=1.1f,createdOn="28/9/2017")
class Employee{
	
	public static void main(String[] args) {
		ArrayList list=new ArrayList();
			list.add(34);
	}
}


