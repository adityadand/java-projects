
public class Calculate {
	public static void main(String... args) {
		Calculate c=new Calculate();
		System.out.println(c);
	}
}

/*class Employee{
	int id;
	String name;
	char gender;
	double fees;
	int asn;
	public Employee(int id, String name, char gender, double fees, int asn) {
		this(id, name, gender, fees);
		this.asn = asn;
		this.display();
	}
	public Employee(int id, String name, char gender, double fees) {
		this.id = id;
		this.name = name;
		this.gender = gender;
		this.fees = fees;
	}
	public void display(){
		System.out.println("Test");
	}
	
	
	
	
}*/