import java.util.Date;


public class Emp {
		
	public static void test(){
		System.out.println(new Date());
	}
	public static void main(String[] args) {
	test();
	}
}
