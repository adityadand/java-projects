package com.demo;
import com.seed.*;

class TestPackage{
	 public static void main(String[] args){

		System.out.println("This is from Test Class");
		A a=new A();
		a.display();
	}
}