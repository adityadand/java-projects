import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;


public class StackTraceDemo {
public static void main(String[] args) {
	StackTraceDemo st=new StackTraceDemo();
		st.m1();
}

public void m1(){
	System.out.println("I am in m1");
	m2();
}

public void m2(){
	try{
		System.out.println(10/0);
	}
	catch (Exception e) {
		System.out.println(e.getClass());
		System.out.println(e.getMessage());
		e.printStackTrace();
	}
	System.out.println("I am in m2");
}


}
