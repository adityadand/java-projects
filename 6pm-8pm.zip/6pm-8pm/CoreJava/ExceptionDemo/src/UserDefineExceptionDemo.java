import java.util.Scanner;
public class UserDefineExceptionDemo {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter Name : ");
	String name=scan.next();
	if(name.length()<3){
		try{
			throw new UserException();
		}catch(UserException ue){
			ue.invalidNameMessage();
		}
	}else{
		System.out.println("Name Is valid... \n Your Name is  "+name);
	}
}
}
class UserException extends Exception{
	public void message(){
		System.err.println("This is User define exception with custom message");
	}
	
	public void invalidNameMessage(){
		System.err.println("This is Invalid name");
	}
}