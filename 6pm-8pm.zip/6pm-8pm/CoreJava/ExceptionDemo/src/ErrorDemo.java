
public class ErrorDemo {
public static void main(String[] args) {
//	new ErrorDemo().m1();
}

/*public void m1(){
	System.out.println("I am m1");
	m2();
}

public void m2(){
	System.out.println("I am m2");
	m1();
}*/
}
