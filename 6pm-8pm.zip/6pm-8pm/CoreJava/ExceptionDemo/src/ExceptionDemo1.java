import java.io.File;


public class ExceptionDemo1 {
	
	public static void main(String[] args) {
		System.out.println("Main Starts");
		try{ // come with catch or finally or both
			System.out.println(args[0]);
			System.out.println(10/0);
		}
		catch(ArrayIndexOutOfBoundsException | StringIndexOutOfBoundsException  e){
			System.err.println("Cannot Perform Operation");
		}
		finally{
			
		}
		/*catch(IndexOutOfBoundsException e){
			System.err.println("Cannot Perform Operation");
		}*/
		
		
			//new File("").createNewFile();
		System.out.println("Main Ends");
	}
}
