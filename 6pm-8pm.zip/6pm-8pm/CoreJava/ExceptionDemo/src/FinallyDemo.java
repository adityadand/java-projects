import java.util.InputMismatchException;
import java.util.Scanner;

public class FinallyDemo {
	public static void main(String[] args) {
	
		try(Scanner scan = new Scanner(System.in);)
		{
			
			System.out.println("Enter 1st Number : ");
			int a = scan.nextInt();
			System.out.println("Enter 2nd Number : ");
			int b = scan.nextInt();
			
			System.out.println("Div : " + a / b);
		} catch (ArithmeticException e) {
			System.err.println("Cannot / by 0");
		}
		catch (InputMismatchException e) {
			System.err.println("Enter Numeric Values only");
		}

	}
}
