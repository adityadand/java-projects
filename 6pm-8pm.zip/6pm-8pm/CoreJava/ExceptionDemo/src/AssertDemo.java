import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;


public class AssertDemo {
public static void main(String[] args) throws FileNotFoundException {
	//System.setOut(new PrintStream(new FileOutputStream("D:\\files\\test.txt",true)));
	System.setOut(new PrintStream("D:\\files\\test.txt"));
	System.out.println(65);
}
}


