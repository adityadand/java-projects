package AbstractClass;

abstract public class AbstractClassDemo {
public static void main(String[] args) {
	System.out.println("I m Main from abstract");
}
}
abstract class Bike{
	abstract public void company();
	abstract public void features();
}
abstract class Honda extends Bike{
}
abstract class Activa extends Honda{
	
}



