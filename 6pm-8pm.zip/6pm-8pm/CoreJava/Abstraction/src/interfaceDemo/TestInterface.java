package interfaceDemo;

public class TestInterface {
public static void main(String[] args) {
}
}
interface I1{
	int a=10;
	public void m1();
}
interface I2 extends I1{
	int b=20;
	public void m2();
}
class Demo extends Innova implements I1,I2 {
	public void m1(){}
	public void m2(){}
}



/**
 *1. All member of interface are public
 *2. all methods are abstract
 *3. all Variable are public static and final
 *4. one interface can extends one or more than 1 interface
 *5. concrete class or abstract class can implement one or more than one interface
 *6. cannot create constructor.
 *7. cannot have static and final methods.
 *8. cannot create object of interfaces but can be use as a reference.
 *9. every interface gets own .class file
 */
interface Vehical{
	int a=10; 
	void companyName();
	void featurs();
	void noOfWheels();
}
interface Engine{
	public void power();
}

abstract class Car implements Vehical,Engine{
	public void noOfWheels() {
		System.out.println("Car has 4 wheels..");
	}
}
abstract class Toyota extends Car{
	public void companyName() {
		System.out.println("Company Name : Toyota");
	}
}

class Innova extends Toyota{
	public void featurs(){
		
	}

	@Override
	public void power() {
		// TODO Auto-generated method stub
		
	}
}








