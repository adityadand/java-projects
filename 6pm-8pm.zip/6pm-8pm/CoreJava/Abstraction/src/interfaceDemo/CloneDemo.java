package interfaceDemo;

public class CloneDemo implements Cloneable{
	int a;
public static void main(String[] args) throws CloneNotSupportedException {
	CloneDemo d1=new CloneDemo();
	d1.a=20;
	
	
	CloneDemo d2=(CloneDemo)d1.clone();
	d1.a=30;
	
	System.out.println(d1 +" - "+d1.a);
	System.out.println(d2 +" - "+d2.a);
}
}