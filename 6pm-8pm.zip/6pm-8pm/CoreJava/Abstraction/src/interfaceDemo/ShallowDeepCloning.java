package interfaceDemo;

public class ShallowDeepCloning {
public static void main(String[] args) throws CloneNotSupportedException {
	Address a1=new Address("Pune");
	Employee e1=new Employee(12,a1);
	
	Employee e2=(Employee)e1.clone();
	
	e1.id=13;
	e1.add.city="Mumbai";
	
	Employee e3=(Employee)e2.clone(); 
	
	e3.add.city="delhi";
	e1.display();
	e2.display();
	e3.display();
}
}

class Employee implements Cloneable{
	int id;
	Address add;
	public Employee(int id, Address add) {
		this.id = id;
		this.add = add;
	}
	public void display(){
		System.out.println(this +"\t"+id + " \t "+ add.city);
	}
	protected Object clone() throws CloneNotSupportedException {
		String city=add.city;
		Address a=new Address(city);
		Employee e=new Employee(id, a);
		return e; // deep cloning
		//return super.clone(); // shallow cloning
	}
}
class Address{
	String city;
	public Address(String city) {
		this.city=city;
	}
}