package interfaceDemo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

abstract public class InterfaceDemo {
public static void main(String[] args) {
	Mobile mobile=new Note5();
	mobile.print();
}
}
interface Printer{
	public void print();
}
interface Product{
	public void model();
	public void price();
	public void company();
}
interface Vehical1 extends Product{
}
interface Mobile extends Product,Printer{
	void screenSize();
}
abstract class Lenovo implements Mobile{
	public void company(){
		System.out.println("Company is Lenovo");
	}
}
class Note5 extends Lenovo implements Printer{
	public void screenSize() {
		System.out.println("5 Inch");
	}
	public void model() {
		System.out.println("Note5 - N5432");
	}
	public void price() {
		System.out.println("rs. 10000 only");
	}
	
	public void print(){
		company();
		model();
		screenSize();
		price();
	}

	
}

