package com.seed;


public class A{
	private int a=10;
	protected void display(){
		int a=10;
		System.out.println("I am From A Class");
	}

	 public static void main(String[] args){
		A a=new A();
		a.display();

	}
}

class B{
public void display(){
		System.out.println("I am From B Class");
	}
}