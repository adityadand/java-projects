




class Student
{
	private int id;
	private int age;
	public Student(int id,int age){
		this.id=id;
		this.age=age;
	}
	public void displayStudent(){
		System.out.println("Id : "+id);
		System.out.println("Age : "+age);
	}

}

class TestEncapsulation
{
	public static void main(String a[]){
		Student stud=new Student(12,23);
		stud.displayStudent();
	}

}