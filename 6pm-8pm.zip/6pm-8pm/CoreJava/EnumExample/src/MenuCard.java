import java.util.Scanner;


public enum MenuCard {
	
	tea("TEA","Special Tea",20),
	coffee("COFFEE","Bru Coffee",30),
	juice("Mango Juice","Mango Juice",40);
	
	String title,desc;
	double price;
	
	private MenuCard(String title,String desc,double price ) {
		this.title=title;
		this.desc=desc;
		this.price=price;
	}
	
	public void display(){
		System.out.println(title +"\t"+desc+"\t"+price);
	}
	
	
}
