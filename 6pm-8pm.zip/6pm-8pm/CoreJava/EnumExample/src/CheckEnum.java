
public class CheckEnum {
public static void main(String[] args) {
	/*System.out.println(MenuCard.tea);
	System.out.println(MenuCard.coffee);
	System.out.println(MenuCard.juice);*/
	
	for (MenuCard menu : MenuCard.values()) {
		menu.display();
	}
	
}
}
 
