package seed.gui;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;

public class Frame2 extends JFrame{
	
	public Frame2(){
		setSize(400, 300);
		
		
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	@Override
	public void paint(Graphics g) {
		super.paint(g);
		g.setColor(Color.red);
		g.fillOval(50, 40, 100, 100);
		
		g.drawString("SEED", 150, 150);
	}

}
