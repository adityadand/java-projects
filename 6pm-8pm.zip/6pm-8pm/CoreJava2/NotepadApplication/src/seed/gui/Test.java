package seed.gui;

public class Test {

	public static void main(String[] args) {
		//new MainFrame();
		new Frame2();
	}
}
