package seed;

public abstract class Account {

	public abstract void calculate();
	public  void display(){
		
		
	}
}
