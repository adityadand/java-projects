package seed.db;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class Test {

	public static void main(String[] args) {
		
		Connection con = null;
		Statement stmt = null;
		
		//PreparedStatement stmt = null;
		
		ResultSet rs = null;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@aquarius.parth.com:1521:oracle11", "java", "java");
			
			System.out.println("Connection done");
			
			DatabaseMetaData dbData = con.getMetaData();
			
			System.out.println("Name: "+dbData.getDatabaseProductName());
			System.out.println("Version: "+dbData.getDatabaseProductVersion());
			
			stmt = con.createStatement();

			rs = stmt.executeQuery("select * from login");

			ResultSetMetaData rsData = rs.getMetaData();
			
			int columns = rsData.getColumnCount();
			
			for(int count=1; count <= columns; count++)
				System.out.print(rsData.getColumnLabel(count)+"\t");
			
			System.out.println();
			
			while(rs.next()){
				for(int count=1; count <= columns; count++)
					System.out.print(rs.getString(count)+"\t");
				
				System.out.println();
			}
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				rs.close();
				stmt.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		//Class.forName("com.mysql.jdbc.Driver");
		//con = DriverManager.getConnection("jdbc:mysql://localhost:3306/system", user, password)
		
	}

}
// Update
/*stmt = con.prepareStatement("insert into login values(?,?)");

String username = "Spring";
String password = "Spring";

stmt.setString(1, username);
stmt.setString(2, password);

int rows = stmt.executeUpdate();
*/
//int rows = stmt.executeUpdate("insert into login values('"+username+"','"+password+"')");

//System.out.println(rows+" row inserted");


/*
 * Noremal select
 * 
 * stmt = con.createStatement();

rs = stmt.executeQuery("select * from login");

System.out.println("Empid \t Name \t Salary ");
while(rs.next()){				
	System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getInt(3));
	
}*/

