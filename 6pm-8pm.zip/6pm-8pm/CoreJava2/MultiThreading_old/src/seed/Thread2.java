package seed;

public class Thread2 implements Runnable{

	@Override
	public void run() {
		try {
			for(int count=0; count<10; count++){
				System.out.println("Thread2: "+count);
				Thread.sleep(100);  // delay
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
