package seed;

public class Thread1 extends Thread{

	@Override
	public void run() {
		try {
			for(int count=0; count<10; count++){
				System.out.println("Thread1: "+count);
				Thread.sleep(100);  // delay
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
