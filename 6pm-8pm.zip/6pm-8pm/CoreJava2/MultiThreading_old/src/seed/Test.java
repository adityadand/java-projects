package seed;

import gui.MainFrame;
import gui.MainFrame2;

public class Test {

	public static void main(String[] args) {
		
		//GUI
		
		new MainFrame2();
		
		
		/*// extends Thread
		
		Thread1 objThread1 = new Thread1();
		
		// implements Runnable
		
		Thread2 target = new Thread2();
		Thread objThread = new Thread(target);
		
			
		//objThread1.setDaemon(true);
		
		
		objThread1.setPriority(1);
		objThread.setPriority(10);
		
		//System.out.println(objThread1.getPriority());
		//System.out.println(objThread.getPriority());
		
		objThread1.start();
		objThread.start();
		
		try {
			objThread1.join();
			objThread.join();
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try {
			for(int count=0; count<10; count++){
				System.out.println("main: "+count);
				Thread.sleep(100);  // delay
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		

	}

}
