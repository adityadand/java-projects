package gui;

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class MainFrame extends JFrame{
	
	JButton btnStart = new JButton("Start");
	
	int xPos1 = 10;
	int xPos2 = 400;
	
	public MainFrame(){
		setSize(500, 400);
		setLayout(null);
		
		btnStart.setBounds(400, 0, 100, 20);
		
		btnStart.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			
				new AnimationThread().start();
			}
		});
		
		add(btnStart);
		
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	@Override
	public void paint(Graphics g) {
		super.paint(g);
		
		g.drawString("SEED", xPos1, 100);
		g.drawString("Infotech", xPos2, 300);
	}
	
	class AnimationThread extends Thread{
		
		@Override
		public void run() {
			try {
				while (true) {
					xPos1++;
					xPos2--;				
					repaint();
					Thread.sleep(10);
				}
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}

}
