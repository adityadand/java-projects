package gui;

import gui.MainFrame.AnimationThread;

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class MainFrame2 extends JFrame{

JButton btnStart = new JButton("Start");
	
	int x = 10;
	int y = 40;
	int xRect = 50;
	
	public MainFrame2(){
		setSize(500, 400);
		setLayout(null);
		
		btnStart.setBounds(400, 0, 100, 20);
		
		btnStart.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			
				new AnimationThread().start();
			}
		});
		
		
		this.addMouseMotionListener(new MouseMotionListener() {
			
			@Override
			public void mouseMoved(MouseEvent e) {
				xRect = e.getX();
				repaint();
				
			}
			
			@Override
			public void mouseDragged(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		
		add(btnStart);
		
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	@Override
	public void paint(Graphics g) {
		super.paint(g);
		
		g.fillOval(x, y, 30, 30);
		g.fillRect(xRect, 360, 100, 20);
	}
	
	class AnimationThread extends Thread{
		
		@Override
		public void run() {
			try {
				while (true) {
					x++;
					y++;				
					repaint();
					Thread.sleep(10);
				}
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}

}
