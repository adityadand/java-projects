package seed.gui;

import java.awt.FlowLayout;
import java.util.Vector;

import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class RegisterFrame extends JFrame{

	JLabel lblUsername = new JLabel("Username");
	JLabel lblPassword = new JLabel("Password");
	
	JTextField tfUsername = new JTextField(25);
	JTextField tfPassword = new JTextField(25);
	
	JCheckBox cbJava = new JCheckBox("Java");
	JCheckBox cbNet = new JCheckBox(".Net");
	
	ButtonGroup gender = new ButtonGroup();
	
	JRadioButton rbMale = new JRadioButton("Male");
	JRadioButton rbFemale = new JRadioButton("Female");
	
	JComboBox<String> cbQualification = new JComboBox<String>(); 
	
	JList<String> listOflanguages = new JList<String>();
	
	Vector<String> data = new Vector<>();
	
	public RegisterFrame(){
		setSize(400, 500);
		setLayout(new FlowLayout());
		
		add(lblUsername);
		add(tfUsername);
		
		add(lblPassword);
		add(tfPassword);
		
		add(cbJava);
		add(cbNet);
		
		gender.add(rbFemale);
		gender.add(rbMale);
		
		add(rbMale);
		add(rbFemale);
		
		cbQualification.addItem("BCA");
		cbQualification.addItem("BCS");
		cbQualification.addItem("MCA");
		cbQualification.addItem("BE");
		cbQualification.addItem("ME");
		
		add(cbQualification);
		
		data.add("Java");
		data.add("Struts");
		data.add("Spring");
		data.add("Hibernate");
		data.add("Servlet");
		
		listOflanguages.setListData(data);
		
		add(listOflanguages);
		
		JList<String> listOfLanguages2 = new JList<String>();
		
		String[] data2 = {"Struts","C","CPP",".Net"};
		
		listOfLanguages2.setListData(data2);
		
		add(listOfLanguages2);
		
		setVisible(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}
	
}
