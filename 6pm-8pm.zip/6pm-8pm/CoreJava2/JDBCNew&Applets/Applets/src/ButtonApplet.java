import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JApplet;
import javax.swing.JButton;


public class ButtonApplet extends JApplet{

	JButton btnRed = new JButton("Red");
	JButton btnGreen = new JButton("Green");
	JButton btnBlue = new JButton("Blue");
	
	@Override
	public void init() {
		
		setLayout(new FlowLayout());
		
		btnRed.addActionListener(new ButtonHandler());
		btnGreen.addActionListener(new ButtonHandler());
		btnBlue.addActionListener(new ButtonHandler());
		
		add(btnRed);
		add(btnGreen);
		add(btnBlue);
	}
	
	class ButtonHandler implements ActionListener{
		
		@Override
		public void actionPerformed(ActionEvent e) {
		
			ShapeApplet obj = (ShapeApplet) ButtonApplet.this.getAppletContext().getApplet("shape");
			
			switch(e.getActionCommand()){
			case "Red":
				obj.setColor(Color.red);
				break;
			case "Green":
				obj.setColor(Color.green);
				break;
			case "Blue":
				obj.setColor(Color.blue);
				break;
			}
			
			obj.repaint();
			
		}
	}
	
}
