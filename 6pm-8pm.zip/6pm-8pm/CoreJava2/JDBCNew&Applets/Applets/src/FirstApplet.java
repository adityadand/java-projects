import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JApplet;


public class FirstApplet extends JApplet{

	String fontname;
	int size;
	
	@Override
	public void init() {
		
		fontname = getParameter("fontname");
		size = Integer.parseInt(getParameter("size"));
	}
	
	
	@Override
	public void paint(Graphics g) {
		super.paint(g);
		
		g.setFont(new Font(fontname, Font.BOLD, size));
		g.drawString("Applet", 50, 50);
	}
	
	/*@Override
	public void start() {
		System.out.println("start");
	}
	
	@Override
	public void stop() {
		System.out.println("stop");
	}
	
	@Override
	public void destroy() {
		System.out.println("destroy");
	}*/
	
}
