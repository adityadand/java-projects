import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JApplet;


public class ShapeApplet extends JApplet{

	Color color = Color.black;
	
	@Override
	public void paint(Graphics g) {
		super.paint(g);
		
		g.setColor(color);
		g.fillOval(50, 50, 100, 100);
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}
	
	
}
