package seed.db;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;

public class Test {

	public static void main(String[] args) {
		
		Connection con = null;
		CallableStatement stmt = null;
		
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@aquarius.parth.com:1521:oracle11", "java", "java");
			
			System.out.println("Connection done");
			
			stmt = con.prepareCall("{call addnum(?,?,?)}");
			
			stmt.setInt(1, 20);
			stmt.setInt(2, 20);
			stmt.setInt(3, 0);
			
			stmt.registerOutParameter(3, Types.INTEGER);
			
			stmt.execute();
			
			System.out.println(stmt.getInt(3));
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		
	}

}
