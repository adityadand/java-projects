package udp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class Server {

	public static void main(String[] args) {
		
		try(DatagramSocket socket = new DatagramSocket(5050)){
			
			byte[] buffer = new byte[4086];
			
			DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
			
			System.out.println("Server ready...");
			
			socket.receive(packet);
			
			System.out.println("Client message: "+new String(buffer));
			
			String message = "This is server message";
			
			packet = new DatagramPacket(
					message.getBytes(), message.length(), InetAddress.getLocalHost(), 5656);
			
			socket.send(packet);
			
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
