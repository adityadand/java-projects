package udp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

public class Client {

	public static void main(String[] args) {
		
		try(DatagramSocket socket = new DatagramSocket(5656)){
			
			InetAddress address = InetAddress.getByName("www.facebook.com");
			
			String message = "Hello Server, this is UDP "+address.getHostName()+" : "+address.getHostAddress();
			
			DatagramPacket packet = new DatagramPacket(
					message.getBytes(), message.length(), InetAddress.getLocalHost(), 5050);
			
			socket.send(packet);
			
			System.out.println("Client is waiting for data");
			
			
			byte[] buffer = new byte[4086];
			
			DatagramPacket packet2 = new DatagramPacket(
					buffer, buffer.length);
			
			socket.receive(packet2);
			
			System.out.println(new String(buffer));
			
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
