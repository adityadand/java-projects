package chatting;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class ChatServer {

	public static void main(String[] args) {
		
		ServerSocket server = null;
		Socket client = null;
		
		Scanner scanner = new Scanner(System.in);
		DataInputStream dis = null;
		DataOutputStream dos = null;
		
		try {
			server = new ServerSocket(4848);
			System.out.println("Server ready...");
			
			client = server.accept();
			System.out.println("Client connected: "+client.getRemoteSocketAddress());
			
			dis = new DataInputStream(client.getInputStream());
			dos = new DataOutputStream(client.getOutputStream());
			
			while(true){
				System.out.println(dis.readUTF());
				dos.writeUTF(scanner.nextLine());
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				dis.close();
				dos.close();
				scanner.close();
				client.close();
				server.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
