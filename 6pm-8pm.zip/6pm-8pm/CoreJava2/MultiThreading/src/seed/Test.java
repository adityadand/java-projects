package seed;

import gui.MainFrame;


public class Test {

	public static void main(String[] args) {
		
		new MainFrame();
		
		/*Account objAccount = new Account();
		
		// extends Thread
		
		Thread1 objThread1 = new Thread1(objAccount);
		
		// implements Runnable
		
		Thread2 target = new Thread2(objAccount);
		Thread objThread = new Thread(target);
		
		
		objThread1.start();
		objThread.start();*/
				

	}

}
