package seed;


public class Thread2 implements Runnable{

	Account objAccount = null;
	
	public Thread2(Account objAccount) {
		super();
		this.objAccount = objAccount;
	}

	@Override
	public void run() {
		for(int count=0; count<10; count++)
			objAccount.deposite(100);	
		
	}

}
