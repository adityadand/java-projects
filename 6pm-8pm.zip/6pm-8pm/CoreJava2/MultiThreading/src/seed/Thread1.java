package seed;

public class Thread1 extends Thread{

	Account objAccount = null;
	
	public Thread1(Account objAccount) {
		super();
		this.objAccount = objAccount;
	}

	@Override
	public void run() {
		
			for(int count=0; count<10; count++)
				objAccount.withdraw(100);		
		
	}
}
