package seed;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Account {

	private int balance = 1000;
	
	Lock objLock = new ReentrantLock();
	
	public  void withdraw(int amount){
		
		try {
			objLock.lock();
				balance -= amount;
				Thread.sleep(100);
				System.out.println("Withdraw: " + balance);
			objLock.unlock();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public  void deposite(int amount){
		try {
			objLock.lock();
				balance += amount;
				Thread.sleep(100);
				System.out.println("Deposit: " + balance);
			objLock.unlock();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}



/*public  void withdraw(int amount){
	
	try {
		synchronized (this) {
			balance -= amount;
			Thread.sleep(100);
			System.out.println("Withdraw: " + balance);
		}
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

public  void deposite(int amount){
	try {
		synchronized (this) {
			balance += amount;
			Thread.sleep(100);
			System.out.println("Deposit: " + balance);
		}
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}*/