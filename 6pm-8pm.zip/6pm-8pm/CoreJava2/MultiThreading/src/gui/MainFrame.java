package gui;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;

public class MainFrame extends JFrame implements Runnable{
	
	int xRed = 5;
	int xGreen = 5;
	int xBlue = 5;
	
	public MainFrame(){
		setSize(500, 400);
		
		Thread redThread = new Thread(this, "Red");
		Thread greenThread = new Thread(this, "Green");
		Thread blueThread = new Thread(this, "Blue");
		
		redThread.start();
		greenThread.start();
		blueThread.start();
		
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	@Override
	public void paint(Graphics g) {
		super.paint(g);
		
		g.setColor(Color.red);
		g.fillOval(xRed, 50, 20, 20);
		
		g.setColor(Color.green);
		g.fillOval(xGreen, 100, 20, 20);
		
		g.setColor(Color.blue);
		g.fillOval(xBlue, 150, 20, 20);
	}

	@Override
	public void run() {
		try {
			while (true) {
				if (Thread.currentThread().getName().equals("Red")) {

					if(xRed >= getWidth()-20){
						synchronized (this) {
							wait();
						}
					}
					
					xRed++;
					Thread.sleep(5);

				} else if (Thread.currentThread().getName().equals("Green")) {

					if(xGreen >= getWidth()-20){
						synchronized (this) {
							wait();
						}
					}
					
					xGreen++;
					Thread.sleep(15);

				} else {

					if(xBlue >= getWidth()-20){
						synchronized (this) {
							notifyAll();
						}
						
						xRed = xGreen = xBlue = 5;
					}
					
					xBlue++;
					Thread.sleep(25);
				}
				
				repaint();
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
