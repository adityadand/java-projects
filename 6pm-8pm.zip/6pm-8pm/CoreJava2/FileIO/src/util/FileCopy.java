package util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileCopy {

	public static void main(String[] args) throws IOException{
		
		FileInputStream fis = null;
		FileOutputStream fos = null;
		
		try {
			fis = new FileInputStream("First.txt");
			fos = new FileOutputStream("Second.txt", true);
			
			int data = 0;
			
			while((data = fis.read()) != -1)
				fos.write(data);
			
			System.out.println("File io complete");	
						
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			fis.close();
			fos.close();
		}
			
		
	}
}
