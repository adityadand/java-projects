package util;

import java.io.Serializable;

public class Employee implements Serializable{

	transient int empid;
	String name;
	double salary;
	
	static int count = 0;
	
	public Employee(int empid, String name, double salary) {
		super();
		this.empid = empid;
		this.name = name;
		this.salary = salary;
	}
	public Employee() {
		super();
	}
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", name=" + name + ", salary="
				+ salary + "]";
	}
	
	
	
}
