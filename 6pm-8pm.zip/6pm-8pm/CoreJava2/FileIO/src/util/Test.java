package util;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		
		write();
		read();
	}

	private static void read() {
		
		try(DataInputStream dis = new DataInputStream(new FileInputStream(new File("Employee.txt")))){
			
			System.out.println(dis.readInt());
			System.out.println(dis.readUTF());
			System.out.println(dis.readDouble());
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private static void write() {
		
		// try with resources  or ARM   Java 7
		try(DataOutputStream dos = new DataOutputStream(new FileOutputStream("Employee.txt"))){
			
			try(Scanner scanner = new Scanner(System.in)){
				
				System.out.println("Enter empid:");
				int empid = scanner.nextInt();
				
				System.out.println("Enter name:");
				String name = scanner.next();
				
				System.out.println("Enter salary:");
				double salary = scanner.nextDouble();
				
				dos.writeInt(empid);
				dos.writeUTF(name);
				dos.writeDouble(salary);
				
				System.out.println("Write complete");
				
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
