package gui;

import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JProgressBar;
import javax.swing.JTable;

public class ProgressFrame extends JFrame{
	
	JProgressBar bar = new JProgressBar();
	
	public ProgressFrame(){
		
		setSize(300, 200);
		setLayout(new FlowLayout());
		
		String[] columnNames = {"empid","name","basicSalary"};
		
		String[][] rowData = {
				{"101","Xyz","2000"},
				{"101","Xyz","2000"},
				{"101","Xyz","2000"},
				{"101","Xyz","2000"},
				{"101","Xyz","2000"},
		};
		
		JTable table = new JTable(rowData, columnNames);
		
		table.setBounds(10, 30, 300, 130);
		
		add(table);
		
		bar.setBounds(10, 150, 250, 20);
		bar.setStringPainted(true);
		
		add(bar);
		
		setVisible(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
		
		/*int value = 0;
		
		try {
			while(value <= 100){
				bar.setValue(value);
				value++;
				Thread.sleep(100);
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		dispose();*/
	}

}
