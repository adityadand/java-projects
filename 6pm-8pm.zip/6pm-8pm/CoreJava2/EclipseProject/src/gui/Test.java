package gui;

public class Test {

	public static void main(String[] args) {
		
		new ProgressFrame();
		//new MainFrame();
	}
}
