package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class MainFrame extends JFrame{
	
	
	JLabel lblCords = new JLabel("X: Y:");
	
	JButton btn = new JButton();
	
	/*JButton btn1 = new JButton("Btn1");
	JButton btn2 = new JButton("Btn2");
	JButton btn3 = new JButton("Btn3");
	JButton btn4 = new JButton("Btn4");*/
	
	
	public MainFrame(){
		setSize(500, 400);
		setLayout(null);
		
		
		lblCords.setBounds(200, 30, 100, 20);
		
		add(lblCords);
		
		this.addMouseMotionListener(new MouseMotionListener() {
			
			@Override
			public void mouseMoved(MouseEvent e) {
				
				int x = e.getX();
				int y = e.getY();
				
				lblCords.setText("X: "+x+" Y: "+y);
				
			}
			
			@Override
			public void mouseDragged(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		
		/*btn1.setBounds(20, 50, 100, 20);
		btn2.setBounds(50, 100, 100, 20);
		btn3.setBounds(100, 150, 100, 20);
		btn4.setBounds(200, 200, 100, 20);
		
		add(btn1);
		add(btn2);
		add(btn3);
		add(btn4);
		*/
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

}
