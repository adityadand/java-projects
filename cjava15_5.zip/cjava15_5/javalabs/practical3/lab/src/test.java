
public class test {
	
	
	public void swapbyval(int d,int d1,int m,int m1,int y,int y1){
		int temp;
		
		temp=d;
		d=d1;
		d1=temp;
		temp=m;
		m=m1;
		d1=temp;
		temp=y;
		y=y1;
		y1=temp;
		
	}

	
	 public void swapbyrev(Date dat,Date dat1)
   {
		 int temp;
		 temp=dat.day;
		 dat.day=dat1.day;
		 
		 dat1.day=temp;
		 temp=dat.month;
		 dat.month=dat1.month;
		 
		temp=dat.year;		 
		 dat.year=dat1.year;
		 dat1.year=temp;
   }
	
	public static void main(String[] args) {
		
		Date dat = new Date();
		Date dat1 = new Date();
		dat.initdate(5,12,2018);
		dat1.initdate(6,12,2019);
		
	
		test dt1 = new test();
		
		dt1.swapbyrev(dat,dat1);
		
		dat.display();
		dat1.display();
		
		
	}

}
