
public class Employee {
	
	int empid;
	String name;
	Date da;
	
	
	Employee(int id,String name,Date da)
	{   empid=id;
		this.name=name;
		this.da=da;
	}
   
	 void display(){
		 
		 System.out.println(empid);
		 System.out.println(name);
		 System.out.println(da.day+","+da.month+","+da.year);
		 
	 }

	public static void main(String[] args) {
		Date da = new Date();
		da.initdate(12,12,2012);
		Employee em = new Employee(12,"sammy",da);
		em.display();
		
		


	}

}
