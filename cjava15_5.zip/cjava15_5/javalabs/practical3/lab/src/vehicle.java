/**
 * 
 * @author aditya
 * @since 2017
 * @version v.0
 * 
 * 
 */
public class vehicle {
	
	
	public void getDetail()
	{
		System.out.println("can play,can pause");
	}

	public static void main(String[] args) {
		
	}

}

class car extends vehicle{
	
	public void getDetail()
	{
		System.out.println("car can play,can pause");
	}
	
}

class bike extends vehicle{
	
	public void getDetail()
	{
		System.out.println(" bike can play,can pause");
	}
	
}
class superbike extends bike{
	
	public void getDetail()
	{
		System.out.println(" superbike can play,can pause");
	}
	
}
class simplebike extends bike{
	
	public void getDetail()
	{
		System.out.println(" simplebike can play,can pause");
	}
	
}
class supercar extends car{
	
	public void getDetail()
	{
		System.out.println(" simplecar can play,can pause");
	}
	
}

class simplecar extends car{
	
	public void getDetail()
	{
		System.out.println(" simplecar can play,can pause");
	}
	
}

class lamborghini extends supercar{
	
	public void getDetail()
	{
		System.out.println(" simplecar can play,can pause");
	}
	
}

class ferrari extends supercar{
	
	public void getDetail()
	{
		System.out.println(" simplecar can play,can pause");
	}
	
}



class nano extends simplecar {
	
	public void getDetail()
	{
		System.out.println(" simplecar can play,can pause");
	}
	
}




