
public class Date {
	public int day,month,year;

	
	
	public void initdate(int day,int month,int year){
		        this.day=day;
				this.month=month;
				this.year=year;
				 
		//System.out.println(day+"-"+month+"-"+year);
	}
	
	public void display()
	{
		System.out.println(day+"-"+month+"-"+year);
	}

	public static void main(String[] args) { 
		
		
		

	}

}
