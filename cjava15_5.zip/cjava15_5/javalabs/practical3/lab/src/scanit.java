import java.util.Scanner;;

public class scanit {
	

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("enter ur name");
		String name=scan.nextLine();
		System.out.println("helo mr "+name);
		System.out.println("enter your age");
		int age =scan.nextInt();
		System.out.println(age);
		

	}

}
