
public class vehicleDetail
{
	vehicle ve = new vehicle();
	int car;
	int bike;
	
	public void vehdet(vehicle ve)
	{
	  ve.getDetail();
		
	}
	
	public void bikedet(bike bi)
	{
	  bi.getDetail();
		
	}
	
	public void cardet(car ca)
	{
	  ca.getDetail();
		
	}
	
	


	public static void main(String[] args) {
		//car ca = new car();
		//bike bi = new bike();
		//vehicle ve = new vehicle();
		vehicleDetail ved = new vehicleDetail();
		//ved.vehdet(new supercar());
		//bike bd = new bike();
		//car cd =new car();
		ved.bikedet(new simplebike());
		ved.cardet(new supercar());
		
	


	}

}
