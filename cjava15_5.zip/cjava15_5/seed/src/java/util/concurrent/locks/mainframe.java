//import java.awt.Color;
//import java.awt.Graphics;
//
//
//import javax.swing.JFrame;
//
//public class mainframe extends JFrame {
//	
//	
//	
//	public mainframe() {
//
//	setLayout(null);
//	setSize(400,500);
//	setVisible(true);
//		
//	}
//	
//	
//	
//	
//	
//	@Override
//	public void paint(Graphics g) {
//		
//		
//		g.setColor(Color.red);
//		g.fillOval(200, 100, 20, 20);
//		
//		g.setColor(Color.CYAN);
//		g.fillOval(200, 100, 20, 20);
//		
//		g.setColor(Color.magenta);
//		g.fillOval(200, 100, 20, 20);
//		
//		
//		
//		super.paint(g);
//	}
//	
//	
//
//	
//	public static void main(String[] args) {
//		
//
//	}
//
//}
