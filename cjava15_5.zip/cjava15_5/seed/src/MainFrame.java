

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JColorChooser;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class MainFrame extends JFrame{

	JMenuBar menubar = new JMenuBar();
	
	JMenu menuFile = new JMenu("File");
	JMenu menuEdit = new JMenu("Edit");
	
	JMenuItem[] arrMenuItems = new JMenuItem[7];
	String[] arrNames = {"New","Open","Save","Exit","Cut","Copy","Paste"};
	
	JTextArea taData = new JTextArea();
	
	JPopupMenu popupMenu = new JPopupMenu();
	JMenuItem menuColor = new JMenuItem("Color");
	
	public MainFrame(){
		setSize(500, 400);
		
		for(int var=0; var<arrMenuItems.length; var++){
			arrMenuItems[var] = new JMenuItem(arrNames[var]);
			
			arrMenuItems[var].addActionListener(new MenuHandler());
			
			if(var < 4)
				menuFile.add(arrMenuItems[var]);
			else
				menuEdit.add(arrMenuItems[var]);
		}
		
		menubar.add(menuFile);
		menubar.add(menuEdit);
		
		setJMenuBar(menubar);
		
		taData.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				int button = arg0.getButton();				
				if(button == 3)
					popupMenu.show(MainFrame.this, arg0.getX(), arg0.getY());
				
			}
		}); //
		
		JScrollPane scPane = new JScrollPane(taData);
		
		add(scPane);
		
		menuColor.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Color color = JColorChooser.showDialog(MainFrame.this, "Select Color", null);
				taData.setBackground(color);
				
			}
		});
		popupMenu.add(menuColor);
		
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	
	class MenuHandler implements ActionListener{
		
		JFileChooser fileSelector = new JFileChooser();
		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			
			switch(arg0.getActionCommand()){
			case "New":
				taData.setText("");
				break;
			case "Open":
				fileSelector.showOpenDialog(MainFrame.this);
				break;
			case "Save":
				fileSelector.showSaveDialog(MainFrame.this);
				break;
			case "Exit":
				dispose();				
				break;
			case "Cut":
				taData.cut();
				break;
			case "Copy":
				taData.copy();				
				break;
			case "Paste":
				taData.paste();
				break;
			
			}
			
		}
	}

}