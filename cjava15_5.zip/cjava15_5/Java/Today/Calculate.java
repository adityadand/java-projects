class Calculate
{
  public void Addition(int a,int b)
	{
	 int c;
	 c=a+b;
	 System.out.println("Addition 0f Numbers is "+c);  		
	}
  public int Subraction(int a, int b)
	{
	 int c;
	 c=a-b;
 	 return c;
	}
  public static void main(String[] z)
	{
	 int result;
	 Calculate add=new Calculate();
	 add.Addition(1,2);
	 Calculate subract=new Calculate();
	 subract.Subraction(20,5);
	 result=subract.Subraction(20,5);
	 System.out.println("Subraction is "+result);
	}

}