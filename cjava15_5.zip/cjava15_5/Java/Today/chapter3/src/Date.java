public class Date {
	int day;
    int month;
    int year;
    
    Date(int day,int month,int year)
    {   this.day=day;
    	this.month=month;
    	this.year=year;
    }
    
    Date(){
    	day=8;
    	month=28;
    	year=2017;
    }
    
    public void display()
    { 
    	System.out.println(day+"/"+month+"/"+year);
    }
   
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date dat = new Date();
		dat.display();
	}



}
