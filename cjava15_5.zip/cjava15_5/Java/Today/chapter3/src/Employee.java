public class Employee {
     int empid;
     String empname;
     double bsalary;
     double hra;
     double medical;
     double pf;
     double pt=200;
     double nsalary;
     double gsalary;
     
     
    public void calcGsalary(){
    	gsalary=bsalary+getHra()+medical;
    	System.out.println("gross salary= "+gsalary);
    }
     
    public void  calcNsalary(){
    	nsalary=gsalary-(pt+pf);
    	System.out.println("netsalary= "+nsalary);
    }
    
    public void display()
    { 
    	System.out.println("employee id= "+empid);
    	System.out.println("employee name= "+empname);
    	System.out.println("basicsalary= "+bsalary);
    	System.out.println("hra= "+getHra());
    	System.out.println("medical= "+medical);
    	System.out.println("pf= "+getPf());
    	System.out.println("pt= "+pt);
    }
    
	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public double getBsalary() {
		return bsalary;
	}

	public void setBsalary(double bsalary) {
		this.bsalary = bsalary;
	}

	public double getHra() {
		hra=bsalary*0.5;
		return hra;
	
	}

	public double getMedical() {
		return medical;
	}

	public void setMedical(double medical) {
		this.medical = medical;
	}

	public double getPf() {
		pf=bsalary*0.12;
		return pf;
	}



	public double getNsalary() {
		return nsalary;
	}

	public void setNsalary(double nsalary) {
		this.nsalary = nsalary;
	}

	public double getGsalary() {
		return gsalary;
	}

	public void setGsalary(double gsalary) {
		this.gsalary = gsalary;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee emp = new Employee();
		emp.setEmpid(2324);
		emp.setEmpname("zukerberg");
		emp.setBsalary(100000);
		emp.setMedical(80000);
		
		emp.display();
		emp.calcGsalary();
		emp.calcNsalary();
	System.out.println();

	}

}
