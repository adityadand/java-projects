class Mydate
 {
	int dd,mm,yy;
	

public void initdate()
 {
 	dd=24;
	mm=8;
	yy=2017;
	System.out.println("the date is "+dd+mm+yy);
 }
public static void main(String[] a)
 {
 	Mydate object=new Mydate();
	object.initdate();
 }

}