package pack1;

public class student {

public String name="rohit";
public int rollno=5;
public char gen='m';
public int stid=30;
}
