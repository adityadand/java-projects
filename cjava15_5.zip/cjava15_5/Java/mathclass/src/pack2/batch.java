package pack2;
import pack1.student;



public class batch {
	
	public int batchno=1;
    public	String batchname="first batch";

	void display()
	{
		//student s = new student();
	//	System.out.println(s.name);
		/*
		 * System.out.println(s.rollno);
		 System.out.println(s.gen);
		System.out.println(s.stid);
		*/
		
		// all the above variable are not accessable  because the access modifier is not public
	}
	
 public static void main(String[] args) {

	 batch b = new batch();
	 b.display();
	 
}
 
 
 
}
