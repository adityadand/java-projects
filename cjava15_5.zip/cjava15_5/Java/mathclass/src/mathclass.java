
public class mathclass {
	
	//rules in method overloading 
	/*
	 * method name must be same name 
	 * parameter must be different
	 * return data type can or cannot be same
	 * access modifier may or may not be same
	 */
	static void add(int a,int b)
	{
		System.out.println("add of two integer "+(a+b));
	}
	
	static void add(int... a)
	{          int temp=0;
		System.out.println("addition of many int no");
		for (int i = 0; i < a.length; i++) 
		{
			temp=temp+a[i];
			
			
		}
		System.out.println(temp);
	}
	static void add(float c,float d)
	{
		System.out.println("add of two float var "+(c+d));
		
	}
	static void add(String e,String f)
	{
		System.out.println("add of two string "+(e+f));
	}

	public static void main(String[] args) {
	 
		add(5,5,5,5,4,4,5,45,4,3,4,6,5,3,4,6,3);

	}

}
