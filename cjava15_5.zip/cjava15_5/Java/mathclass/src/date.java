
public class date
{
	
	int day;
	int month;
	int year;
	
	/*
	 * this is first statement in a constructor
	 * this is used in
	 * methods
	 * constructor
	 * and variables
	 */
	
	
	
	date(int d,int m,int y){
	
		this(d,m);
		year=y;
	
	}
	
	 date(int d,int m ){
		day=d;
		month=m;
		}
	
	 void display()
		{
			System.out.println(day+","+month+","+year);
			
		}
		
	
	
	


public static void main(String[] args)
{
	date dat = new date(12,4,1956);
	dat.display();
}

}

