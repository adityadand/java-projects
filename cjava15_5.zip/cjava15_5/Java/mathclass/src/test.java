import pack1.student;
import pack2.batch;

public class test {
	
	



	public static void main(String[] args) {
		
		student s = new student();
		batch b = new batch();
		System.out.println(s.name);
		System.out.println(s.rollno);
		System.out.println(s.gen);
		System.out.println(s.stid);
		System.out.println(b.batchno);
		System.out.println(b.batchname);
		
		System.out.println(Runtime.getRuntime().freeMemory()/(1024*1024));


	}

}
