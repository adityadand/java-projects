
public class employee {
	
	
	int empid;
	String name;
	int bsalary;
	static int id;
   
    
    employee(String n,int sal){
    	 
    	  name=n;
    	bsalary=sal;
    	 id=id+1;
    	 empid=id;
    	 
    }
	
	
	static void totalemp()
	{ 
		System.out.println(id);
	}
	
	void display()
	{
		System.out.println(name);
		System.out.println(bsalary);
		System.out.println(empid);
			}


	public static void main(String[] args)
	{
	      employee e = new employee("ramesh",10000);
	      employee e1 = new employee("suresh",20000);
	      e.display();
	 	  e1.display();
	 	  employee.totalemp();
	     
	      
	 }

}
