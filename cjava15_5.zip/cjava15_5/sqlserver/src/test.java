import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;


public class test {

	
	public static void main(String[] args) {
		
		Connection con = null;
		Statement stmt = null;
		
		ResultSet rs =null;
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@aquarius.parth.com:1521:oracle11","java","java");
			
			System.out.println("connection...done");
			
			DatabaseMetaData dbdata = con.getMetaData();
			System.out.println("name:"+dbdata.getDatabaseProductName());
			System.out.println();
			
			stmt = con.createStatement();

			stmt.execute("create table aditya0078(name varchar(50),age int)");
			
			/*ResultSetMetaData rsdata =rs.getMetaData();
			
			int columns =  rsdata.getColumnCount();
			
			for(int count=1;count<=columns;count++){
				System.out.println(rsdata.getColumnLabel(count)+"\t");
				System.out.println();
				
				
				while(rs.next()){
					for( count=1; count <= columns; count++)
						System.out.print(rs.getString(count)+"\t");
					
					System.out.println();
				}
				
				
			}
			*/
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
		
			
			try {
				rs.close();
				stmt.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
				
			
		}
		
		
		
		
	}
}
