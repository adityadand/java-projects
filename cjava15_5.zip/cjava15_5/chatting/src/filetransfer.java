import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.Buffer;
import java.util.Scanner;

public class filetransfer {

public static void main(String[] args) {
	ServerSocket server = null;
	Socket client = null;
	Scanner scan = new Scanner(System.in);
	DataInputStream dis = null;
	DataOutputStream dos = null;
	FileInputStream fis = null;
	
	
	try {
		
		server = new ServerSocket(5000);
		System.out.println("i am ready - server");
		client = server.accept();
		System.out.println("client connected..."
				+ client.getRemoteSocketAddress());
		dis = new DataInputStream(client.getInputStream());
		dos = new DataOutputStream(client.getOutputStream());
		File fi = new File(dis.readUTF());
		
		 fis = new FileInputStream("C:\\Users\\cjava15_5\\Desktop\\heo.txt");
		
	
		if(fi.exists())
		{ long  a = fi.length();
			dos.writeUTF("file do exist");
			dos.writeUTF("file size =" + a);
			dos.writeUTF("do u want the file y/n");
			String b = dis.readUTF();
			if(b.equals("y")){
				dos.writeUTF("sending");
				
				byte d[] = new byte [10000];
				int e;
			
				while((e=fis.read(d))!=0){
				dos.write(d);
				
				
			}
			
			}
			
			
			
		}else{
			dos.writeUTF("file do not exist");
		}
		
		System.out.println("Please send message...");

		
	/*	while(true)
		{
			System.out.println(dis.readUTF());
			dos.writeUTF(scan.nextLine());
		}
		*/
		
		
	} 
	
	catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
	}finally
	{
		try {
			
			
			dis.close();
			dos.close();
			scan.close();
			client.close();
			server.close();
			fis.close();
		} catch (Exception e2) {
			// TODO: handle exception
		}
	}
		
	  
}

}
		