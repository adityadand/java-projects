import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class ChatClient {

	public static void main(String[] args) {
		
		Socket client = null;
		
		Scanner scanner = new Scanner(System.in);
		DataInputStream dis = null;
		DataOutputStream dos = null;
		
		
		
		// 127.0.0.1   or IP
		try {
			client = new Socket("192.168.5.69", 5100);
			
			dis = new DataInputStream(client.getInputStream());
			dos = new DataOutputStream(client.getOutputStream());
			
			System.out.println("Please send message...");
			while(true){
				dos.writeUTF(scanner.nextLine());
				System.out.println(dis.readUTF());
			}
			
		} catch (UnknownHostException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				dis.close();
				dos.close();
				scanner.close();
				client.close();
			} catch (IOException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
		}
	}
}

	


