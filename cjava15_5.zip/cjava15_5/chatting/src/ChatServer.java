import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;





public class ChatServer {

public static void main(String[] args) {
	ServerSocket server = null;
	Socket client = null;
	Scanner scan = new Scanner(System.in);
	DataInputStream dis = null;
	DataOutputStream dos = null;
	try {
		
		server = new ServerSocket(5000);
		System.out.println("i am ready - server");
		client = server.accept();
		System.out.println("client connected..."
				+ client.getRemoteSocketAddress());
		dis = new DataInputStream(client.getInputStream());
		dos = new DataOutputStream(client.getOutputStream());
		
		while(true)
		{
			System.out.println(dis.readUTF());
			dos.writeUTF(scan.nextLine());
		}
		
		
		
	} 
	
	catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
	}finally
	{
		try {
			dis.close();
			dos.close();
			scan.close();
			client.close();
			server.close();
		} catch (Exception e2) {
			// TODO: handle exception
		}
	}
		
	  
}

}
		
	

	
	

