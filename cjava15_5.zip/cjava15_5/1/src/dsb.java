
public class dsb {

	
	public static void main(String[] args) {
	

	/*	String ak47="012323010";
		
		int a = Integer.parseInt(ak47);
		
		System.out.println(a);
		*/
		
		
		String b =Integer.toString(1234);
		System.out.println(b);
		
		String c=Integer.toBinaryString(0);
		System.out.println(c);
		
		int a=10;
		Integer d=a;
		
		
		
		
	}

}
