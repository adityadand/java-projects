import java.util.Scanner;


public class calculator {

	public static void main(String[] args) {
		
		while(true)
		{
		Scanner sc = new Scanner(System.in);
		
         System.out.println("super fast CALCULATOR");
		  System.out.println("1.addition");
		  System.out.println("2.multiplication");
		  System.out.println("3.divide");
		  System.out.println("4.multiplication");
		  System.out.println("5.exit");
		int c,d;
		int a;
		a=sc.nextInt();
		c=sc.nextInt();
		d=sc.nextInt();
	
		
		switch(a){
		
		
		case 1: System.out.println("addition of 2 no is");
		       System.out.println(c+d);
		         break;
		         
		case 2: System.out.println("multiplication of 2 no is");
		       System.out.println(c*d);
		        break;
		        
		case 3: System.out.println("divide of 2 no is");
		       System.out.println(c/d);
		        break;
		        
		case 4: System.out.println("subsctraction of 2 no is");
		        System.out.println(c-d);
		         break;
		         
		case 5: System.exit(0);
		         
		         default:  System.out.println("are u mad no case given");
		
		
		}
		

	}

}
}

