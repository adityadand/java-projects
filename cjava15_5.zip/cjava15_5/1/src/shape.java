
abstract public class shape {

	
	abstract void area();
	
	
	
	public static void main(String[] args) {
		
		 rectangle rect = new rectangle();
			rect.area();
		    rect.print();
		

	}

}

class rectangle extends shape implements printable{
	int area;
	 void area(){
		 int l=5,b=6;
		 area=l*b;
		 
	 }
		
		 
		public void print(){
			
			System.out.println(area);
			
		}
		 
		 
	 }
	


