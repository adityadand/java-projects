
public class fortest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
	byte b=1;
	int i=0,j=1;
	
	
	while(b<=128)
	{
			System.out.println(j+"\t"+i+"\t"+j+"\t"+i+"\t"+j+"\t"+i+"\t"+j+"\t"+i+"\t"+j+"\t"+i+"\t"+j+"\t"+i);
			System.out.println(j+"\t"+i+"\t"+j+"\t"+i+"\t"+j+"\t"+i+"\t"+j+"\t"+i+"\t"+j+"\t"+i+"\t"+j+"\t"+i);
		b++;
			
		
	}
	}
	}



