import java.util.Scanner;


public class tester {

	
	public static void main(String[] args) {
       
	
		//int ch=0;
		
		String str;
 
		Scanner sc = new Scanner(System.in);
		//ch=sc.nextInt();
		
		System.out.println("type y to decide your luck else tap n to exit");
		
		str=sc.nextLine();
		
		if(str.equals("y") || str.equals("Y")) {
			
			int a=(int) (Math.random()*5);
			
			System.out.println(a);
			
			switch(a){
			
			case 1: System.out.println("gate to the heaven");
		              break;
		              
			case 2: System.out.println("path to the hell");
			
			case 3: System.out.println("eternity immortal");
			
			default: System.out.println("you are at no place");
			
			}
			
			
		}
		else{
			
			System.exit(0);
			
		}
 
		
		
		
		
	}

}
