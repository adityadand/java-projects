
public class stringdemo {

	public static void main(String[] args) {
		
		
		StringBuffer b = new StringBuffer("live");
		System.out.println("before reverse");
		System.out.println(b);
		b.reverse();
		System.out.println("after reverse");
		System.out.println(b);

	}

	}


