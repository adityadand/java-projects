
public class employee implements printable{
	
	int eid=1000;
	String ename="yamraj";
	double esalary=120000;


	public static void main(String[] args) {
		
		employee e = new employee();
		e.print();
		


	}


	@Override
	public void print() {
		System.out.println(eid);
		System.out.println(ename);
		System.out.println(esalary);
		
	}

}
