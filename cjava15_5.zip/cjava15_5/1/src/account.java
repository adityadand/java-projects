
public class account {

	int accid=123;
	String ahname="gooogle";
	double balance=138381890802839.00;
	
	
	
	
	class locker{
		int locid=007;
		
	  public 	void locdisp(){
		System.out.println("locid = "+locid);
		System.out.println("accid = "+accid);
		System.out.println("ahname = "+ahname);
		System.out.println("balance = "+balance);
			
		}
		
		
		
		
		
	}
	
		public static void main(String[] args) {
			account.locker l = new account().new locker();
			l.locdisp();
	

	}

}

