
public class date1 implements Cloneable {
int day=7,month=7,year=7;
	
	public void print(){
		System.out.println("day = "+day+" month= "+month+" year = "+year);
	}
	
	@Override
		protected Object clone() throws CloneNotSupportedException {
			// TODO Auto-generated method stub
			return super.clone();
		}
	


	public static void main(String[] args) throws CloneNotSupportedException {
		date1 dt = new date1();
	
		
	date1 dt1 = (date1) dt.clone();
	
	dt.day=8;
	dt.month=9;
	dt.year=2050;
	
	dt.print();
     dt1.print();
     
     
}

}