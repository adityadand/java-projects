
public class date implements printable{
	
	int day=7,month=7,year=7;
	
	public void print(){
		System.out.println("day = "+day+" month= "+month+" year = "+year);
	}
	


	public static void main(String[] args) {
		
		date dt = new date();
		dt.print();
	
	}

}
