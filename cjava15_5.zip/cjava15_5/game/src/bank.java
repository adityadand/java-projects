import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public class bank {
	
	int balance=1000;
	
	
	
 Lock l = new ReentrantLock();
		
	public int withdraw (bank bank ,int amount){
		
			l.lock();
			synchronized (bank) {
				int amount1 = 100;
				amount1 = amount;
				balance = balance - amount1;
			}
			return balance;
		
		} 
		
		
	
	
	
	public  int deposit (bank bank ,int amount){
		
			
			synchronized (bank) {
				int amount1 = 100;
				amount1 = amount;
				balance = balance + amount1;
				return balance;
			}
		
		
		}
		
		
	}
	
	
	
	
	
	

