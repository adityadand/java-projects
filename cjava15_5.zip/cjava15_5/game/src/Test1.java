

public class Test1 {

	public static void main(String[] args) {
		
		//new ProgressFrame();
		new MainFrame1();
	}
}
