

import java.awt.Color;
import java.awt.Graphics;


import javax.swing.JFrame;

public class Mainframe extends JFrame implements Runnable{
	
	int xpos=10,xpos1=10,xpos2=10;
	
	public Mainframe() {

	setLayout(null);
	setSize(400,500);
	
	Thread obj = new Thread(this,"Red");
	obj.start();
	
	Thread obj1 = new Thread(this,"Cyan");
	obj1.start();
	
	Thread obj2 = new Thread(this,"magenta");
	obj2.start();
	
	setVisible(true);
	setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	
	
	
	
	@Override
	public void paint(Graphics g) {
		
		super.paint(g);
		
		
		g.setColor(Color.red);
		g.fillOval(xpos, 100, 20, 20);
		
		g.setColor(Color.CYAN);
		g.fillOval(xpos1, 200, 20, 20);
		
		g.setColor(Color.magenta);
		g.fillOval(xpos2, 300, 20, 20);
		
		
		
		
		
		
		
		
	}
	
	
@Override
public void run() {
	
	try {
		
		while(true)
		{
		if(Thread.currentThread().getName().equals("Red"))
		{
			xpos++;
			Thread.sleep(0);
			
			if(xpos>=getWidth()-20){
				synchronized (this) {
					wait();
				}
			}
		}
		else if(Thread.currentThread().getName().equals("Cyan")){
			xpos1++;
			Thread.sleep(0);
		
			if(xpos1>=getWidth()-20){
				synchronized (this) {
					wait();
				}
			}
		}
		else{
			xpos2++;
			Thread.sleep(0);
			
			if(xpos2>=getWidth()-20){
				synchronized (this) {
					notifyAll();
				xpos=10;
				xpos1=10;
				xpos2=10;
				}
			}
		}
		
		repaint();
		}
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
	
	
}
