
public class withdraw extends Thread {
	
bank bank2;
	
	 public withdraw(bank b1){
		bank2 = b1;
	}

	
	@Override
	public void run() {
	
		for (int i=0; i<=10; i++) {
			
		
		int a = bank2.withdraw(bank2, 100);
		
		System.out.println(a);
		super.run();
		}
	}
}

