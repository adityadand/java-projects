

import java.awt.ScrollPane;
import java.awt.TextArea;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public class MainFrame1 extends JFrame{
	
	
	public MainFrame1(){
		setSize(500, 400);
		
		DefaultMutableTreeNode root = new DefaultMutableTreeNode("EclipseProject");
		
		DefaultMutableTreeNode binNode = new DefaultMutableTreeNode("bin");
		DefaultMutableTreeNode srcNode = new DefaultMutableTreeNode("src");
		
		DefaultMutableTreeNode guiNode = new DefaultMutableTreeNode("gui");
		
		DefaultMutableTreeNode mainframeNode = new DefaultMutableTreeNode("MainFrame.java");
		DefaultMutableTreeNode testNode = new DefaultMutableTreeNode("Test.java");
		
		guiNode.add(mainframeNode);
		guiNode.add(testNode);
		
		srcNode.add(guiNode);
		
		root.add(binNode);
		root.add(srcNode);
		
		JTree tree = new JTree(root);
		
		JTabbedPane tabPane = new JTabbedPane();
		
		tabPane.add("MainFrame.java", new JScrollPane(new JTextArea()));
		tabPane.add("Test.java",new TextArea());
		
		JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, tree, tabPane);
		
		splitPane.setDividerLocation(150);
		
		add(splitPane);
		
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

}
