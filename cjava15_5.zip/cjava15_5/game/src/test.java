
public class test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
                
	/*	bank b3 = new bank();
		withdraw wit = new withdraw(b3);
		deposit dep = new deposit(b3);
		
		wit.start();
		dep.start();*/
		new Mainframe();

	}

}
