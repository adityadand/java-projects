
public class deposit extends Thread {
bank bank1;
	
	public deposit(bank b) {
		bank1 = b;
	}

	
	@Override
	public void run() {
	
		for (int i=0; i<=10; i++) {
			
		
		int b = bank1.deposit(bank1, 100);
		
		System.out.println(b);
		super.run();
	}
	}
}
