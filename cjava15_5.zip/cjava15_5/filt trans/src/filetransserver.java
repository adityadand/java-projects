import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
//import java.io.FileOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class filetransserver {
	public static void main(String[] args) throws IOException {
		ServerSocket server=null;
		Socket client=null;
		DataInputStream dis=null;
		DataOutputStream dout=null;
		FileInputStream fis=null;
		//FileOutputStream fos=null;
		try {
				server=new ServerSocket(5005);
				System.out.println("Server ready....");
				client=server.accept();
				System.out.println("Client connected:"+client.getRemoteSocketAddress());
				
				dis=new DataInputStream(client.getInputStream());
				dout=new DataOutputStream(client.getOutputStream());
//				fis=new FileInputStream("filetransfersocket");
//				fos=new FileOutputStream("filetransfersocket");
				
				String name=dis.readUTF();
				System.out.println(name);
				File f1=new File("C:\\Users\\Public\\Pictures\\Sample Pictures\\"+name);
				if(f1.exists())
				{
					dout.writeUTF("File Exists");
					long lenfile=f1.length();
					dout.writeLong(lenfile);
					
					fis=new FileInputStream(f1);
					byte[] buffer = new byte[4096];
					
					while(fis.read(buffer)!=-1){
						dout.write(buffer);
					}
					
					System.out.println("File copied.");
				}
				else
				{
					dout.writeUTF("File does not exists");
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		finally
		{
			dout.close();
			dis.close();
		}
		
	}

}
