

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class MainFrame extends JFrame{

	JLabel lblUsername = new JLabel("Username");
	JLabel lblPassword = new JLabel("Password");
	
	JButton btnSubmit = new JButton("Submit");
	JButton btnClear = new JButton("Clear");
	JButton btnRegister = new JButton("Register");
	
	JTextField tfUsername = new JTextField(25);
	JPasswordField tfPassword = new JPasswordField(25);
	
	JLabel lblError = new JLabel();
	
	public MainFrame(){
		setSize(400, 400);
		setLayout(new FlowLayout());
		setTitle("Swing application");
		
		add(lblUsername);
		add(tfUsername);
		
		add(lblPassword);
		add(tfPassword);
		
		btnSubmit.addActionListener(new ButtonHandler());
		btnClear.addActionListener(new ButtonHandler());
		btnRegister.addActionListener(new ButtonHandler());
		
		add(btnSubmit);
		add(btnClear);
		add(btnRegister);
		
		add(lblError);
		
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	class ButtonHandler implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent ae) {
			String command = ae.getActionCommand();
			
			switch(command){
			case "Submit":
				String username = tfUsername.getText();
				char[] password = tfPassword.getPassword();
				
				String pass = new String(password);
				
				int length = pass.length();
				
				if(length >= 8)				
					System.out.println("Welcome "+username+" password: "+pass);
				else
					lblError.setText("Password should have 8 chars");
					//JOptionPane.showMessageDialog(MainFrame.this, "Password should have 8 chars");
					
				break;
			case "Clear":
				tfUsername.setText("");
				tfPassword.setText("");
				break;
			case "Register":
				new RegisterFrame();
				break;
			}
		}
	}
}
