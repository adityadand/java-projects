import java.util.Scanner;
public class test extends Thread {

	@Override
	public void run() {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter no");
		int a=sc.nextInt();
		
		try {
			for(int count=a; count<10; count++){
				System.out.println(count);
				Thread.sleep(100);
			}
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
}


