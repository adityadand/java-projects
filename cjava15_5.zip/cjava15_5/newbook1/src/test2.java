import java.util.Scanner;
public class test2 implements Runnable{

	@Override
	public void run() {
Scanner sc = new Scanner(System.in);
		
		System.out.println("enter no");
		int b=sc.nextInt();
		int c;
		
		try {
			for(int count=1; count<10; count++){
				c=b*count;
			System.out.println(c);
				Thread.sleep(100);
				
			}
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		
	}


