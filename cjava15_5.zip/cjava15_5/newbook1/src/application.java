import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;


public class application extends JFrame {
	
	JButton btnStart= new JButton("Start");
	
	public application(){
		setSize(500, 400);
		setLayout(null);
		btnStart.setBounds(400, 0, 100, 20);
		add(btnStart);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
btnStart.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			
				new AnimationThread().start();
			}
		});

	}
	
	int xpos1=250,xpos2=250;
	@Override
	public void paint(Graphics g) {
		super.paint(g);
		g.drawString("bomb", xpos1, 250);
		g.drawString("blast", xpos2, 250);
	}
	
class AnimationThread extends Thread{
		
		@Override
		public void run() {
			try {
				while (true) {
					xpos1++;
					xpos2--;
					if(xpos2==0){
						xpos2=250;
					}
					if(xpos1==500){
						xpos1=250;
					}
					repaint();
					Thread.sleep(10);
				}
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
}
}


