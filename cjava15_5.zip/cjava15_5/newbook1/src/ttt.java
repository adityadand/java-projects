
public class ttt {


	public static void main(String[] args) {
		
		application app = new application();
		
		
		/*test t = new test();
		t.start();
		
		test2 t2 = new test2();
		Thread th = new Thread(t2);
		th.start();*/
 
	}

}
