import java.util.List;


public class utilitylist {

public void printlist(List l){
	
	System.out.println(l);
	
	
	
	
	
	
	
	
	
}


}
