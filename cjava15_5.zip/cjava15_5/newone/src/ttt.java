import java.io.File;
import java.io.ObjectInputStream.GetField;


public class ttt {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		 File f = new File("C:\\Users\\cjava15_5\\Desktop\\d");
		 File f3 = new File("C:\\Users\\cjava15_5\\Desktop\\yay");
	/*	String[] a=f.list();
		 
		 for (String f1 : a) {
			 
			 System.out.println(f1);
			 
			
		}*/
		 
		//String c = f.getName();
		 
		/* for (String str : c) {
			
		System.out.println(f);
		 
		 
	
		 } */
		 
		 File Files[]=f.listFiles();
		
	
		 for(File f1: Files)
		 {
			
		
		 
		
		String str=f1.getName();
		
		if(str.endsWith(".class")){
			
			
			f1.delete();
			
			
		}
		
		 }
		
		String[] a=f.list();
		 
		 for (String f2 : a) {
			 
			 System.out.println(f2);
			 
			
		}
		 
		// String a1="hello";
		 
		f.renameTo(f3);
		
			
		
	
	}
}
			
			
			
		
		 
	


