import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
public class employee  {
 
	
	  Set skillset;
	 int eid;
	 String  name;
	 double salary;
	 
	
		
public employee(Set skillset, int eid, String name, double salary) {
		super();
		this.skillset = skillset;
		this.eid = eid;
		this.name = name;
		this.salary = salary;
	}




public String toString() {
	
	return (eid+"-"+name+"-"+salary+"-"+skillset);
}		
		
	
	 
	 
	public static void main(String[] args){
		
		HashSet set = new HashSet();
		set.add("bussiness");
		
		employee emp = new employee(set,123,"francis",23213.00);
		employee emp1 = new employee(set,23,"jarvis",1223.00);
		employee emp2= new employee(set,3,"nicole",12213.00);
		employee emp3 = new employee(set,12,"trevor",23213.00);
		employee emp4= new employee(set,13,"michal",13213.00);
		
		
		
		
		ArrayList list = new ArrayList();
		list.add(emp);
		list.add(emp1);
		list.add(emp2);
		list.add(emp3);
		list.add(emp4);
		
		
		//System.out.println(list);
		
		utilitylist li = new utilitylist();
		
		li.printlist(list);
		
		utilityreport  ur = new utilityreport();
		
		ur.showreport(list);
		
		System.out.println("--------------------------------------------------------");
		
		
		sortutil lo = new sortutil();
		lo.sortbysalary(list);
		
		
		
	


	}

}


