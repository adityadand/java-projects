import java.util.Iterator;
import java.util.List;


public class utilityreport {
	
	
	


 public void showreport(List l1){
		
		 Iterator it=l1.iterator();
		 
		 while (it.hasNext()) {
			 employee e =(employee) it.next();
			 
			 System.out.println(e.name+"-"+e.salary);
			
		}
		
				
				
			
		 
	
		 
		 
		 
	 }
	
	
		
		
	}


