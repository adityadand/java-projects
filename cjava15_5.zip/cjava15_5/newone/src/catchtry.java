import java.io.File;
import java.io.IOException;
import java.util.Scanner;


public class catchtry {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		
		File fi =new File("C:\\Users\\cjava15_5\\Desktop\\gyevgui\\new.txt");
		
		/**/
		try{
			int a,b;
			
			a=sc.nextInt();
			b=sc.nextInt();
			
			System.out.println(a/b);
			
			}
		
			
			
			
			
			catch (ArithmeticException e) {
			
			
				
				System.out.println("no error do what u want");
				
				
			}
		
		
		final int az=1000;
		
	//	az=3000;
		
		System.out.println(az);
		
/*finally{
	
	sc.close();
		System.out.println("FINALLY");	
		}
		
		
		System.out.println("CAN U REACH TILL HERE");
		
		

	}*/

	}}
