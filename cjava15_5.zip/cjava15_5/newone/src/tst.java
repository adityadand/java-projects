import java.io.File;
import java.io.IOException;


public class tst {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException   {
	// File f = new File("C:\\Users\\cjava15_5\\Desktop\\wow");
	 
	// f.mkdir();
	// f.createNewFile();

	
	 //System.out.println( f.isHidden());
	 
	/*File[] a=f.listFiles();
	 
	 for (File f1 : a) {		
	
//System.out.println(f1);

System.out.println(f1.list());*/
	 
	}
}
