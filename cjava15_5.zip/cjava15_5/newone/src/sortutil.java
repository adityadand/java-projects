import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


public class sortutil{
	
	public void sortbysalary(List list){
	Comparator cmp = new Comparator<employee>() 
			{

				@Override
				public int compare(employee e1, employee e2) {
					if(e1.salary>e2.salary)
						return 1;
					else if(e1.salary<e2.salary)
						return -1;
						else return 0;
				}
		
			};
			
		Collections.sort(list,cmp);
		System.out.println(list);
			
	}
}
		
	

