
public class manager extends employee  {
	int pta;
	int fa;
	int oa;
	
	public void calcSal(int pta,int fa,int oa){
		employee e = new employee();
		/*this.pta=pta;
		pta=8*e.bsalary;
		this.fa=fa;
		fa=13*e.bsalary;
		this.oa=oa;
		oa=3*e.bsalary;
		*/
		e.bsalary=0.24*e.bsalary;
		
	}
	
	manager(){
		super();
	}

 
	
	public static void main(String[] args) {
		
		
		
	}

}
