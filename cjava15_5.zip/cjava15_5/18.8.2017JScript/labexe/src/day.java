
public enum day{
	sunday("sunday",0),
	monday("monday",1),
	tuesday("tuesday",2),
	wednesday("wednesday",3),
	thursday("thursday",4),
	friday("friday",5),
	saturday("saturday",6);
	int c;
	String d;
	
	private day(String a , int b){
		this.d=a;
		this.c=b;
	}
		
	}