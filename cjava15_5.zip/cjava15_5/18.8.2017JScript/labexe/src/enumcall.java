
public class enumcall {
	

public static void main(String[] args) {

	
	 
	 for (day  a : day.values()) {
		 System.out.println(a.d+" "+a.c);
		// System.out.println(a.c);
		 
		
		
	}
	 
	 
	

	}

}
