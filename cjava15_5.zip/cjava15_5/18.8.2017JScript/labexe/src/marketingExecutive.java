
public class marketingExecutive extends employee {
	
	int travelledkm;
	
	public void calcSal(int pta,int fa,int oa){
		employee e = new employee();
		e.bsalary=5*e.bsalary;
		e.bsalary=1500+e.bsalary;
	}


	public static void main(String[] args) {
		
	}

}
