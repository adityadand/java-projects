
public class employee {
       
	int empid;
	String ename;
	double bsalary;
	
	public void showDetail(){
		System.out.println(empid);
		System.out.println(ename);
		System.out.println(bsalary);

	}
	
	public employee()
	{ }
	
	
	
	public employee(int empid,String ename,double bsalary){
		this.empid=empid;
		this.ename=ename;
		this.bsalary=bsalary;
		}

	
	public static void main(String[] args) {

	

	}

}


